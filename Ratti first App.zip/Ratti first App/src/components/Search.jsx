import React from 'react'


const Search = ({searchTerm,setSearchTerm}) => {
  return (
    <div>
      <div className="flex items-center gap-2 my-5 ml-2">
        <img src="search.svg" alt="search" className="w-8 pl-2" />
        <input
          className="w-full max-w-lg rounded px-5 py-2 border border-gray-300 focus:border-lime-400 focus:bg-indigo-900 hover:border-yellow-400 bg-transparent text-beige"
          type="text"
          placeholder="search through a million movies"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
    </div>
  )
}

export default Search
