import { useEffect, useState, useCallback } from 'react';
import debounce from 'lodash.debounce';
import Search from './components/Search';
import Spinners from './components/spinners';
import Moviecard from './components/moviecard';
import Login from './Login';
import Sidebar from './components/Sidebar';


// Use the correct TMDB base URL for discovery
const API_BASE_URL = 'https://api.themoviedb.org/3';

const API_KEY = import.meta.env.VITE_TMDB_API_KEY;

const API_OPTIONS = {
  method: 'GET',
  headers: {
    accept: 'application/json',
    Authorization: `Bearer ${API_KEY}` // Capital B and backticks for interpolation
  }
};

const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [movielist, setMovieList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [trendingMovies, setTrendingMovies] = useState([]); // NEW
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('user');
    return stored ? JSON.parse(stored) : null;
  });

  // Save user to localStorage on change
  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
      localStorage.setItem('userSavedAt', Date.now());
    }
  }, [user]);

  // Add favorite movie
  const addFavorite = (movie) => {
    if (!user) return;
    if (!user.favorites.some(fav => fav.id === movie.id)) {
      setUser({ ...user, favorites: [...user.favorites, movie] });
    }
  };

  // Rate a movie
  const rateMovie = (movieId, rating) => {
    if (!user) return;
    setUser({ ...user, ratings: { ...user.ratings, [movieId]: rating } });
  };

  // Fetch most popular movies on mount (for "Trending" section)
  useEffect(() => {
    const fetchPopular = async () => {
      try {
        const response = await fetch(
          `${API_BASE_URL}/discover/movie?sort_by=popularity.desc&language=en-US&page=1`,
          API_OPTIONS
        );
        if (!response.ok) throw new Error('Failed to fetch popular movies');
        const data = await response.json();
        setTrendingMovies(data.results || []);
      } catch (error) {
        console.error('Popular fetch error:', error);
      }
    };
    fetchPopular();
  }, []);

  const fetchMovies = useCallback(async (query = '') => {
    setIsLoading(true);
    setErrorMessage('');
    try {
      const endpoint = query
        ? `${API_BASE_URL}/search/movie?query=${encodeURIComponent(query)}`
        : `${API_BASE_URL}/discover/movie?include_adult=true&include_video=false&language=en-US&page=1&sort_by=popularity.desc`;
      const response = await fetch(endpoint, API_OPTIONS);
      if (!response.ok) {
        throw new Error(`Failed to fetch movies: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      setMovieList(data.results || []);
    } catch (error) {
      setErrorMessage(`Error fetching movies: ${error.message}`);
      console.error('FetchMovies error:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

 

  // Debounced fetchMovies
  const debouncedFetchMovies = useCallback(
    debounce((query) => fetchMovies(query), 500), // 500ms delay
    [fetchMovies]
  );

  useEffect(() => {
    debouncedFetchMovies(searchTerm);
    // Cancel debounce on unmount
    return debouncedFetchMovies.cancel;
  }, [searchTerm, debouncedFetchMovies]);

  if (!user) {
    return <Login onLogin={setUser} />;
  }

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
    localStorage.removeItem('userSavedAt');
  };

  return (
    <div className="flex">
      <Sidebar user={user} onLogout={handleLogout} />
      <main
        className="min-h-screen bg-cover bg-center flex-1 ml-64"
      >
        <div className='pattern'></div>
        <div className='wrapper'>
          {/* Main Website Header */}
          <h1 className="text-5xl font-extrabold text-yellow-400 text-center mt-8 mb-4  tracking-wide">
            The movie paradise
          </h1>
          <header className="flex flex-col items-center">
            <img src="./main.jpg" alt="main banner" className="pl-0 md:pl-20 max-w-full h-auto mx-auto" />
            <h1 className="capitalize text-3xl text-center">
              your portal to all your favorite and trending movies
            </h1>
            <Search searchTerm={searchTerm} setSearchTerm={setSearchTerm}/>
          </header>

          {/* Trending Movies Section */}
          <section className="trendingMovies mb-8">
            <h2 className="text-2xl font-bold mb-2 ml-4">Most Popular Movies</h2>
            <ul className="flex flex-row flex-wrap justify-start gap-4 ml-4">
              {trendingMovies.slice(0, 4).map((movie) => (
                <li key={movie.id} className="list-none">
                  <Moviecard movie={movie} />
                </li>
              ))}
            </ul>
          </section>

          <section className="allMovies">
            <h2 className="text-2xl font-bold mb-2 ml-4">All Movies</h2>
            {isLoading ? (
              <Spinners />
            ) : errorMessage ? (
              <p>{errorMessage}</p>
            ) : (
              <ul className="flex flex-row flex-wrap justify-start gap-4 ml-4">
                {movielist.map((movie) => (
                  <li key={movie.id} className="list-none">
                    <Moviecard movie={movie} onFavorite={addFavorite} onRate={rateMovie} userRatings={user.ratings}/>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;
