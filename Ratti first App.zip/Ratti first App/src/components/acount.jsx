import React from 'react';

const Account = ({ user }) => (
  <div className="p-6">
    <h2 className="text-2xl font-bold mb-4">Account Info</h2>
    <div className="mb-4">
      <p className="font-semibold">Username: <span className="font-normal">{user.username}</span></p>
    </div>
    <div className="mb-4">
      <h3 className="font-semibold mb-1">Favorites</h3>
      {user.favorites.length === 0 ? (
        <p className="text-sm text-gray-500">No favorites yet.</p>
      ) : (
        <ul className="text-sm list-disc ml-4">
          {user.favorites.map(movie => (
            <li key={movie.id}>{movie.title}</li>
          ))}
        </ul>
      )}
    </div>
    <div className="mb-4">
      <h3 className="font-semibold mb-1">Ratings</h3>
      {Object.keys(user.ratings).length === 0 ? (
        <p className="text-sm text-gray-500">No ratings yet.</p>
      ) : (
        <ul className="text-sm list-disc ml-4">
          {Object.entries(user.ratings).map(([movieId, rating]) => (
            <li key={movieId}>
              Movie ID: {movieId} - ⭐ {rating}
            </li>
          ))}
        </ul>
      )}
    </div>
    <div>
      <h3 className="font-semibold mb-1">Last Saved</h3>
      <p className="text-sm">{new Date(localStorage.getItem('userSavedAt') || Date.now()).toLocaleString()}</p>
    </div>
  </div>
);

export default Account;