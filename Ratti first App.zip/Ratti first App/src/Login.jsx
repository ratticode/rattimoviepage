import React, { useState } from 'react';

const Login = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Save user info in localStorage (for demo only, not secure)
    const userData = { username, favorites: [], ratings: {} };
    localStorage.setItem('user', JSON.stringify(userData));
    onLogin(userData);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-indigo-900">
      <div className="mb-6 flex flex-col items-center">
        <h1 className="text-5xl font-extrabold text-yellow-400 text-center mb-4 tracking-wide">
          The movie paradise
        </h1>
        <img
          src="./main.jpg"
          alt="main banner"
          className="max-w-xs md:max-w-md h-auto rounded shadow-lg mb-4"
        />
      </div>
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded shadow-md w-80">
        <h2 className="text-2xl font-bold mb-4 text-center text-indigo-900">Login</h2>
        <input
          className="w-full mb-3 px-3 py-2 border rounded"
          type="text"
          placeholder="Username"
          value={username}
          onChange={e => setUsername(e.target.value)}
          required
        />
        <input
          className="w-full mb-4 px-3 py-2 border rounded"
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          required
        />
        <button className="w-full bg-yellow-400 py-2 rounded font-bold" type="submit">
          Login
        </button>
      </form>
    </div>
  );
};

export default Login;