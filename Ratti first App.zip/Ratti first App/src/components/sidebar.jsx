import React from 'react';
import Account from './acount';

const Sidebar = ({ user, onLogout }) => (
  <aside className="bg-indigo-950 text-white w-64 min-h-screen p-6 flex flex-col gap-6 fixed left-0 top-0 z-10">
    <div>
      <button
        className="bg-yellow-400 text-indigo-900 px-3 py-1 rounded font-bold mb-4"
        onClick={onLogout}
      >
        Logout
      </button>
    </div>
    <Account user={user} />
  </aside>
);

export default Sidebar;