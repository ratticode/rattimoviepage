import React, { useState } from 'react';

const Moviecard = ({ movie, onFavorite, onRate, userRatings }) => {
  // Destructure all needed fields from the movie object
  const { title, poster_path, release_date, original_language, vote_average, id } = movie;
  const [trailerUrl, setTrailerUrl] = useState(null);
  const [rating, setRating] = useState(userRatings?.[movie.id] || '');

  // Prepare formatted values for clarity
  const formattedLang = original_language ? original_language.toUpperCase() : 'N/A';
  const formattedYear = release_date ? release_date.split('-')[0] : 'N/A';

  const fetchAndOpenTrailer = async () => {
    const API_KEY = import.meta.env.VITE_TMDB_API_KEY;
    const res = await fetch(
      `https://api.themoviedb.org/3/movie/${id}/videos`,
      {
        method: 'GET',
        headers: {
          accept: 'application/json',
          Authorization: `Bearer ${API_KEY}`,
        },
      }
    );
    const data = await res.json();
    const trailer = data.results?.find(
      (vid) => vid.type === 'Trailer' && vid.site === 'YouTube'
    );
    if (trailer) {
      window.open(`https://www.youtube.com/watch?v=${trailer.key}`, '_blank', 'noopener,noreferrer');
    } else {
      alert('Trailer not available');
    }
  };

  const handleRate = () => {
    if (onRate && rating) {
      onRate(movie.id, rating);
    }
  };

  return (
    <div className="bg-indigo-900 rounded-lg shadow-2xl p-4 m-2 min-w-[180px] max-w-xs flex flex-col items-center justify-center">
      <img
        src={poster_path ? `https://image.tmdb.org/t/p/w500/${poster_path}` : '/nomovie.jpg'}
        alt={title}
        className="rounded w-full h-64 object-cover mb-2"
      />
      <div className="flex items-center text-white mt-2">
        <span className="sr-only">Language:</span>
        <span className="lang">{formattedLang}</span>
        <span aria-hidden="true" className="mx-1">·</span>
        <span className="sr-only">Year:</span>
        <span className="year">{formattedYear}</span>
      </div>
      <div className="flex items-center mt-2">
        <span
          className="text-[#FFD700] text-lg mr-1"
          aria-label="star"
          role="img"
        >⭐</span>
        <span className="font-semibold text-white">{vote_average ?? 'N/A'}</span>
      </div>
      <button
        className="mt-2 px-3 py-1 bg-yellow-500 text-black rounded transition duration-200 hover:bg-yellow-400 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-yellow-400"
        onClick={fetchAndOpenTrailer}
      >
        Watch Trailer
      </button>
      <button
        className="mt-2 px-3 py-1 bg-yellow-400 text-indigo-900 rounded transition duration-200 hover:bg-yellow-300"
        onClick={() => onFavorite && onFavorite(movie)}
      >
        Save Favorite
      </button>
      {userRatings && userRatings[movie.id] && (
        <p className="text-sm text-green-400">Your rating: {userRatings[movie.id]}</p>
      )}
    </div>
  );
};

export default Moviecard;
